package com.ln42.betterdrops.commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Skeleton.SkeletonType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import com.ln42.betterdrops.Main;
import com.ln42.betterdrops.Tools;

public class PluginCommand implements CommandExecutor {
	// @SuppressWarnings("deprecation")
	private Main plugin;

	public PluginCommand(Main pl) {
		plugin = pl;
	}

	@SuppressWarnings("deprecation")
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		boolean permission = true;
		if (!(sender.isOp())) {
			if (!(sender.hasPermission("bd.Commands"))) {
				permission = false;
				// sender.sendMessage(ChatColor.DARK_RED + "You do not have
				// permission to use this command.");
				// return false;
			}
		}
		if (args.length == 0) {
			sender.sendMessage(ChatColor.RED + "Invalid Arguments. Type /bd help for more info.");
			return false;
		}
		String firstArg = args[0];
		if (args.length == 1) {
			if (firstArg.equals("help")) {
				sender.sendMessage("Usage:");
				sender.sendMessage(ChatColor.BOLD + "/bd help");
				sender.sendMessage("Displays this help.");
				sender.sendMessage(ChatColor.BOLD + "/bd give <item> [player]");
				sender.sendMessage(
						"Gives the specified special item to the specified player. If no player is specified, it gives the item to the player entering the command.");
				sender.sendMessage(ChatColor.BOLD + "/bd spawn <item> [player]");
				sender.sendMessage(
						"Spawns a skeleton holding the specified special item at the specified player's location. If no player is specified, it spawns the skeleton at the location of the player entering the command.");
				sender.sendMessage(ChatColor.BOLD + "/bd list");
				sender.sendMessage("Lists all the special items in BetterDrops1.9.");
				return true;
			} else if (firstArg.equals("list")) {
				if (plugin.getConfig().getBoolean("ShulkerLauncherDrop")) {
					sender.sendMessage(ChatColor.LIGHT_PURPLE + "shulkerBL" + ChatColor.RESET
							+ "-A wand that shoots a shulker bullet at the creature/player you are looking at when used.");
				} else {
					sender.sendMessage(ChatColor.RED + "Shulker Bullet Launcher is disabled.");
				}
				if (plugin.getConfig().getBoolean("TheftWandDrop")) {
					sender.sendMessage(ChatColor.DARK_GRAY + "theftWand" + ChatColor.RESET
							+ "-A wand that steals the item from whatever you hit with it, or moves it out of the target's hand.");
				} else {
					sender.sendMessage(ChatColor.RED + "The Wand of Theft is disabled.");
				}
				if (plugin.getConfig().getBoolean("FlightPotionDrop")) {
					sender.sendMessage(ChatColor.ITALIC + "flightPotion" + ChatColor.RESET
							+ "-A potion that allows you to fly for 30 seconds.");
				} else {
					sender.sendMessage(ChatColor.RED + "Flight Potion is disabled.");
				}
				if (plugin.getConfig().getBoolean("PoweredSkeletons")) {
					sender.sendMessage(ChatColor.AQUA + "iceBow" + ChatColor.RESET
							+ "-A bow that creates an ice layer around the creature/player hit.");
					sender.sendMessage(ChatColor.GOLD + "spaceBow" + ChatColor.RESET
							+ "-A bow that is not affected by gravity and knocks the target creature/player farther than a normal bow.");
					sender.sendMessage(ChatColor.DARK_GREEN + "bazookaBow" + ChatColor.RESET
							+ "-A bow that shoots an exploding arrow.");
					sender.sendMessage(ChatColor.GRAY + "shotgunBow" + ChatColor.RESET
							+ "-A bow that shoots 11 arrows from your inventory in a spread-like a shotgun.");
				} else {
					sender.sendMessage(ChatColor.RED + "Special Bows are disabled.");
				}
				if (plugin.getConfig().getBoolean("SpecialBootsDrop")) {
					sender.sendMessage(ChatColor.RED + "fireBoots" + ChatColor.RESET
							+ "-Boots that give you swiftness, jump boost, fire resistance-and set the block you are standing on on fire. Excellent for deforestation.");
					sender.sendMessage(ChatColor.AQUA + "levitationBoots" + ChatColor.RESET
							+ "-Boots that create a water cushion at your feet, so you do not take fall damage-and can climb walls.");
					sender.sendMessage(ChatColor.GREEN + "skywalkerBoots" + ChatColor.RESET
							+ "-Boots that create a glass block at your feet that decays after a short time.");
				} else {
					sender.sendMessage(ChatColor.RED + "Special Boots are disabled.");
				}
				if (plugin.getConfig().getBoolean("LightningStrikeEgg")) {
					sender.sendMessage(ChatColor.YELLOW + "strikeEgg" + ChatColor.RESET
							+ "-An egg that when thrown targets the nearest player/creature and zaps them with lightning, usually until dead.");
				} else {
					sender.sendMessage(ChatColor.RED + "Lightning Strike Egg is disabled.");
				}
				return true;
			} else {
				sender.sendMessage(ChatColor.RED + "Invalid Arguments. Type /bd help for more info.");
				return false;
			}
		}
		String secondArg = args[1];
		if (secondArg == null) {
			sender.sendMessage(ChatColor.RED + "Invalid Arguments. Type /bd help for more info.");
			return false;
		}
		if (firstArg.equals("give")) {
			if (permission) {
				Inventory inv = Bukkit.createInventory(null, 9, "SpecialInventory");
				ItemStack item = Tools.getSpecialItem(secondArg);
				if (item == null) {
					sender.sendMessage(ChatColor.RED + "That item does not exist");
					return false;
				}
				inv.addItem(item);
				if (args.length == 3) {
					String thirdArg = args[2];
					Player targetPlayer = sender.getServer().getPlayer(thirdArg);
					if (targetPlayer == null) {
						sender.sendMessage(ChatColor.RED + "That player does not exist.");
						return false;
					} else {
						targetPlayer.openInventory(inv);
						return true;
					}
				} else {
					if (!(sender instanceof Player)) {
						sender.sendMessage(ChatColor.RED + "You must specify a player!");
						return false;
					}
					Player player = (Player) sender;
					player.openInventory(inv);
					return true;
				}
			} else {
				sender.sendMessage(ChatColor.DARK_RED + "You do not have permission to use this command.");
			}
		} else if (firstArg.equals("spawn")) {
			if (!(permission)){
				sender.sendMessage(ChatColor.DARK_RED + "You do not have permission to use this command.");
			}
			final ItemStack item = Tools.getSpecialItem(secondArg);
			if (item == null) {
				sender.sendMessage(ChatColor.RED + "That bow does not exist.");
				return false;
			}
			if (args.length == 3) {
				String thirdArg = args[2];
				final Player targetPlayer = sender.getServer().getPlayer(thirdArg);
				if (targetPlayer == null) {
					sender.sendMessage(ChatColor.RED + "That player does not exist.");
					return false;
				}
				final Skeleton sk = targetPlayer.getWorld().spawn(targetPlayer.getLocation(), Skeleton.class);
				new BukkitRunnable() {
					@Override
					public void run() {
						sk.setSkeletonType(SkeletonType.NORMAL);
						if (plugin.getConfig().getInt("PoweredSkeletonNameTagVisibility") != 0) {
							sk.setCustomName("Powered Skeleton");
							if (plugin.getConfig().getInt("PoweredSkeletonNameTagVisibility") == 2) {
								sk.setCustomNameVisible(true);
							} else {
								sk.setCustomNameVisible(false);
							}
						}
						sk.getEquipment().setItemInHand(null);
						sk.getEquipment().setItemInHand(item);
						sk.getEquipment().setItemInHandDropChance((float) 0);
					}
				}.runTaskLater(this.plugin, 15);
				return true;
			} else {
				if (!(sender instanceof Player)) {
					sender.sendMessage(ChatColor.RED + "You must specify a player!");
					return false;
				}
				Player player = (Player) sender;
				final Skeleton sk = player.getWorld().spawn(player.getLocation(), Skeleton.class);
				new BukkitRunnable() {
					@Override
					public void run() {
						sk.setSkeletonType(SkeletonType.NORMAL);
						if (plugin.getConfig().getInt("PoweredSkeletonNameTagVisibility") != 0) {
							sk.setCustomName("Powered Skeleton");
							if (plugin.getConfig().getInt("PoweredSkeletonNameTagVisibility") == 2) {
								sk.setCustomNameVisible(true);
							} else {
								sk.setCustomNameVisible(false);
							}
						}
						sk.getEquipment().setItemInHand(null);
						sk.getEquipment().setItemInHand(item);
						sk.getEquipment().setItemInHandDropChance((float) 0);
					}
				}.runTaskLater(this.plugin, 15);
				return true;
			}
		}
		return false;
	}
}
