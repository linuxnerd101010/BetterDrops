package com.ln42.betterdrops.event.player;

import java.util.Stack;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import com.ln42.betterdrops.Main;
import com.ln42.betterdrops.Tools;

public class PlayerWalk implements Listener {
	private Main plugin;

	public PlayerWalk(Main pl) {
		plugin = pl;
	}

	public static Stack<Block> bridgeBlock = new Stack<Block>();
	private boolean waterTask = false;

	@SuppressWarnings("deprecation")
	@EventHandler
	public void onPlayerWalk(PlayerMoveEvent event) {
		System.out.println("Walk Event Called.");
		Player player = event.getPlayer();
		ItemStack boots = player.getInventory().getBoots();
		if (boots == null)
			return;
		int bootsType = boots.getTypeId();
		if ((bootsType != 317)) {
			return;
		}
		Location fromLoc = event.getFrom();
		Location toLoc = event.getTo();
		double fromX = fromLoc.getX();
		double fromY = fromLoc.getY();
		double fromZ = fromLoc.getZ();
		double toX = toLoc.getX();
		double toY = toLoc.getY();
		double toZ = toLoc.getZ();
		fromX = Math.abs(fromX);
		fromY = Math.abs(fromY);
		fromZ = Math.abs(fromZ);
		toX = Math.abs(toX);
		toY = Math.abs(toY);
		toZ = Math.abs(toZ);
		double deltaX = Math.abs(fromX - toX);
		double deltaY = Math.abs(fromY - toY);
		double deltaZ = Math.abs(fromZ - toZ);
		if (Tools.isSpecialItem(boots, "levitationBoots")) {
			if (deltaY > .1) {
				safeFall(player);
			}
		}
		if (deltaX <= .1) {
			if (deltaY <= .1) {
				if (deltaZ <= .1) {
					return;
				}
			}
		}
		if (Tools.isSpecialItem(boots, "skywalkerBoots")) {
			skyWalk(player);
		}
		if (Tools.isSpecialItem(boots, "fireBoots")) {
			fireWalk(player);
		}
	}

	@SuppressWarnings("deprecation")
	public void skyWalk(final Player player) {
		int decayDelay = plugin.getConfig().getInt("SkywalkBootsBlockDecayDelay");
		//PotionEffect[] pearr = (PotionEffect[]) player.getActivePotionEffects().toArray();
		if (!(player.hasPotionEffect(PotionEffectType.SLOW))){
			player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100, 1));
		}
		//player.removePotionEffect(PotionEffectType.SLOW);
		//player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100, 1));
		Location playerLoc = player.getLocation();
		final Location blockLoc = playerLoc;
		// newPlayerLoc.setY(playerLoc.getY() +2); Elevator boots
		blockLoc.setY(playerLoc.getY() - 1);
		final Block block = blockLoc.getBlock();
		if (bridgeBlock.isEmpty()) {
			bridgeBlock.push(player.getLocation().getBlock());
		}
		if (block.equals(bridgeBlock.peek()))
			return;
		if (block.getType().equals(Material.GLASS))
			return;
		int blockBakmid = blockLoc.getBlock().getType().getId();
		final int blockBak = blockBakmid;
		block.setType(Material.GLASS);
		if (decayDelay > 0) {
			bridgeBlock.push(block);
			new BukkitRunnable() {
				@Override
				public void run() {
					if (!(bridgeBlock.search(block) < 0)) {
						bridgeBlock.remove(bridgeBlock.search(block));
					}
					block.setTypeId(blockBak);
				}
			}.runTaskLater(this.plugin, decayDelay);

		}

	}

	public void fireWalk(Player player) {
		Location playerLoc = player.getLocation();
		Location blockLoc = playerLoc;
		// newPlayerLoc.setY(playerLoc.getY() +2); Elevator boots
		blockLoc.setY(playerLoc.getY());
		final Block block = blockLoc.getBlock();
		if (!(block.getType().equals(Material.AIR)))
			return;
		if (!(player.hasPotionEffect(PotionEffectType.FIRE_RESISTANCE))){
			player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 600, 0));
		}
		if (!(player.hasPotionEffect(PotionEffectType.SPEED))){
			player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2));
		}
		if (!(player.hasPotionEffect(PotionEffectType.JUMP))){
			player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 100, 2));
		}
		//player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
		//player.removePotionEffect(PotionEffectType.SPEED);
		//player.removePotionEffect(PotionEffectType.JUMP);
		block.setType(Material.FIRE);
	}

	public void safeFall(final Player player) {
		if (waterTask == true)
			return;
		Location playerLoc = player.getLocation();
		final Location blockLoc = playerLoc;
		final Block block = blockLoc.getBlock();
		if (block.getType().equals(Material.AIR)) {
			block.setType(Material.STATIONARY_WATER);
			waterTask = true;
			// System.out.println("Task created.");
			new BukkitRunnable() {
				@Override
				public void run() {
					block.setType(Material.AIR);
					waterTask = false;
				}
			}.runTaskLater(this.plugin, 4);
		}
	}
}