package com.ln42.betterdrops.event.inventory;

import java.util.Stack;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitScheduler;

import com.ln42.betterdrops.Main;
import com.ln42.betterdrops.Tools;
import com.ln42.betterdrops.codingforcookies.ArmorEquipEvent;
import com.ln42.betterdrops.codingforcookies.ArmorType;

public class BootsEquipEvent implements Listener {
	private Main plugin;
	int id = 0;
	private boolean waterTask = false;
	public static Stack<Block> bridgeBlock = new Stack<Block>();
	public BootsEquipEvent(Main pl) {
		plugin = pl;
	}

	@EventHandler
	public void onBootsEquip(ArmorEquipEvent event) {
		if (event.getType() == null) {
			return;
		}
		if (event.getType().equals(ArmorType.BOOTS)) {
			ItemStack boots = event.getNewArmorPiece();
			Player player = event.getPlayer();
			if (Tools.isSpecialItem(boots, "fireBoots")) {
				fireWalk(player);
			} else if (Tools.isSpecialItem(boots, "skywalkerBoots")) {
				skyWalk(player);
			} else if (Tools.isSpecialItem(boots, "levitationBoots")) {
				safeWalk(player);
			}
		}
	}

	public void fireWalk(final Player player) {
		final BukkitScheduler scheduler = player.getServer().getScheduler();
		id = scheduler.scheduleSyncRepeatingTask(plugin, new Runnable() {
			@Override
			public void run() {
				Location playerLoc = player.getLocation();
				Location blockLoc = playerLoc;
				blockLoc.setY(playerLoc.getY());
				final Block block = blockLoc.getBlock();
				// if
				// (!(player.hasPotionEffect(PotionEffectType.FIRE_RESISTANCE)))
				// {
				player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 400, 0));
				// }
				// if (!(player.hasPotionEffect(PotionEffectType.SPEED))) {
				player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 80, 2));
				// }
				// if (!(player.hasPotionEffect(PotionEffectType.JUMP))) {
				player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 80, 2));
				// }
				if ((block.getType().equals(Material.AIR))) {
					block.setType(Material.FIRE);
				}
				if (!(Tools.isSpecialItem(player.getEquipment().getBoots(), "fireBoots"))) {
					scheduler.cancelTask(id);
				}
			}
		}, 5L, 4L);
	}

	public void safeWalk(final Player player) {
		final BukkitScheduler scheduler = player.getServer().getScheduler();
		id = scheduler.scheduleSyncRepeatingTask(plugin, new Runnable() {
			@Override
			public void run() {
				if (!(Tools.isSpecialItem(player.getEquipment().getBoots(), "levitationBoots"))){
					scheduler.cancelTask(id);
				}
				if (waterTask == true)
					return;
				Location playerLoc = player.getLocation();
				final Location blockLoc = playerLoc;
				final Block block = blockLoc.getBlock();
				if (block.getType().equals(Material.AIR)) {
					block.setType(Material.STATIONARY_WATER);
					waterTask = true;
					// System.out.println("Task created.");
					new BukkitRunnable() {
						@Override
						public void run() {
							block.setType(Material.AIR);
							waterTask = false;
						}
					}.runTaskLater(plugin, 4);
				}
			}
		}, 5L, 4L);
	}

	public void skyWalk(final Player player) {
		final BukkitScheduler scheduler = player.getServer().getScheduler();
		id = scheduler.scheduleSyncRepeatingTask(plugin, new Runnable() {
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				int decayDelay = plugin.getConfig().getInt("SkywalkBootsBlockDecayDelay");
				//PotionEffect[] pearr = (PotionEffect[]) player.getActivePotionEffects().toArray();
				if (!(player.hasPotionEffect(PotionEffectType.SLOW))){
					player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100, 1));
				}
				//player.removePotionEffect(PotionEffectType.SLOW);
				//player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100, 1));
				Location playerLoc = player.getLocation();
				final Location blockLoc = playerLoc;
				// newPlayerLoc.setY(playerLoc.getY() +2); Elevator boots
				blockLoc.setY(playerLoc.getY() - 1);
				final Block block = blockLoc.getBlock();
				if (bridgeBlock.isEmpty()) {
					bridgeBlock.push(player.getLocation().getBlock());
				}
				if (block.equals(bridgeBlock.peek()))
					return;
				if (block.getType().equals(Material.GLASS))
					return;
				int blockBakmid = blockLoc.getBlock().getType().getId();
				final int blockBak = blockBakmid;
				block.setType(Material.GLASS);
				if (decayDelay > 0) {
					bridgeBlock.push(block);
					new BukkitRunnable() {
						@Override
						public void run() {
							if (!(bridgeBlock.search(block) < 0)) {
								bridgeBlock.remove(bridgeBlock.search(block));
							}
							block.setTypeId(blockBak);
						}
					}.runTaskLater(plugin, decayDelay);

				}
				if (!(Tools.isSpecialItem(player.getEquipment().getBoots(), "skywalkerBoots"))){
					scheduler.cancelTask(id);
				}
			}
		}, 5L, 2L);
	}
}
